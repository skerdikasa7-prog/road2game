import React, { useState, useEffect, useRef } from "react";

// --- CONFIG ---
const STRIPE_PAYMENT_LINK = "https://buy.stripe.com/aFa4gtfbv8sS2y1d9Ygfu03";
const ADSENSE_CLIENT = ""; // es. "ca-pub-xxxxxxxx" (opzionale)

export default function App(){
  const [isPro, setIsPro] = useState(false);
  const [page, setPage] = useState("landing"); // landing | builder

  useEffect(()=>{
    const sid = new URLSearchParams(window.location.search).get("session_id");
    async function verify(sessionId){
      try{
        const res = await fetch(`/api/verify-session?session_id=${sessionId}`);
        if(res.ok){
          const data = await res.json();
          if(data?.isPro){ localStorage.setItem("gb_is_pro","1"); setIsPro(true); }
        }
      }catch(e){ console.error(e); }
    }
    if(sid) verify(sid);
    if(localStorage.getItem("gb_is_pro")==="1") setIsPro(true);
  },[]);

  return (
    <div style={{minHeight:"100vh",background:"radial-gradient(120% 120% at 50% -10%, #14162a 0%, #090909 70%)", color:"#fff", fontFamily:"ui-sans-serif, system-ui"}}>
      <Nav isPro={isPro} onUpgrade={()=>window.location.href=STRIPE_PAYMENT_LINK} onStart={()=>setPage("builder")} />
      {page==="landing" ? <Landing isPro={isPro} onStart={()=>setPage("builder")} /> : <Builder isPro={isPro} />}
      <Footer/>
    </div>
  );
}

function Nav({isPro, onUpgrade, onStart}){
  return (
    <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",gap:12, padding:"18px 20px", position:"sticky", top:0, backdropFilter:"blur(8px)", background:"rgba(0,0,0,.35)", borderBottom:"1px solid rgba(255,255,255,.08)"}}>
      <div style={{display:"flex",alignItems:"center",gap:10}}>
        <img src="/logo.png" alt="Road2Game" style={{height:32}}/>
        <b style={{letterSpacing:.2,fontSize:18}}>Road2Game™</b>
      </div>
      <div style={{display:"flex",alignItems:"center",gap:10, fontSize:14}}>
        <button onClick={onStart} style={btn()}>Start Building</button>
        {isPro ? (
          <span style={{padding:"6px 10px", borderRadius:10, background:"rgba(16,185,129,.2)", border:"1px solid rgba(16,185,129,.3)", color:"#a7f3d0"}}>PRO attivo</span>
        ) : (
          <button onClick={onUpgrade} style={btn()}>Upgrade PRO – 5€/mese</button>
        )}
      </div>
    </div>
  );
}

function Landing({isPro, onStart}){
  return (
    <div>
      <section style={{padding:"60px 20px 20px"}}>
        <div style={{maxWidth:1100, margin:"0 auto", display:"grid", gridTemplateColumns:"1.3fr 1fr", gap:24}}>
          <div>
            <h1 style={{fontSize:44, lineHeight:1.05, margin:"0 0 12px", fontWeight:800}}>La strada più veloce per creare <span style={{color:"#a78bfa"}}>videogiochi</span> con l’AI</h1>
            <p style={{opacity:.8, fontSize:18}}>Road2Game™ trasforma una descrizione in un gioco giocabile. Free con pubblicità; PRO senza ads, più template ed export .zip.</p>
            <div style={{display:"flex",gap:10, marginTop:16}}>
              <button onClick={onStart} style={btn()}>Prova il Builder</button>
              {!isPro && <a href="#pricing" style={btn(false,true)}>Vedi piani</a>}
            </div>
            <ul style={{opacity:.8, marginTop:16, fontSize:14, lineHeight:1.6}}>
              <li>• Prompt IT/EN → gioco runner immediato</li>
              <li>• Template extra in PRO (shooter, platform)</li>
              <li>• Export .html (Free) • Export .zip (PRO)</li>
            </ul>
          </div>
          <div>
            <div style={{background:"linear-gradient(135deg, rgba(167,139,250,.2), rgba(34,211,238,.2))", border:"1px solid rgba(255,255,255,.12)", borderRadius:16, padding:16}}>
              <img src="/logo.png" alt="Logo" style={{display:"block", margin:"0 auto", height:120}}/>
              <div style={{height:220, display:"grid", placeItems:"center", opacity:.8}}>
                <span>Preview gioco qui (builder sotto)</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section id="features" style={{padding:"40px 20px"}}>
        <div style={{maxWidth:1100, margin:"0 auto", display:"grid", gridTemplateColumns:"repeat(3, 1fr)", gap:16}}>
          {["Crea con un prompt","Gioca subito","Esporta e condividi"].map((t,i)=>(
            <div key={i} style={{background:"rgba(255,255,255,.05)", border:"1px solid rgba(255,255,255,.1)", borderRadius:16, padding:16}}>
              <h3 style={{marginTop:0}}>{t}</h3>
              <p style={{opacity:.8, fontSize:14}}>Zero installazioni. Scrivi l’idea, Road2Game fa il resto.</p>
            </div>
          ))}
        </div>
      </section>

      <section id="pricing" style={{padding:"40px 20px"}}>
        <div style={{maxWidth:1100, margin:"0 auto"}}>
          <h2 style={{marginTop:0, fontSize:28}}>Piani</h2>
          <div style={{display:"grid", gridTemplateColumns:"1fr 1fr", gap:16}}>
            <div style={card()}>
              <h3>Free</h3>
              <p style={{opacity:.8}}>Per iniziare</p>
              <ul style={{opacity:.85, fontSize:14, lineHeight:1.6}}>
                <li>• Genera & gioca</li>
                <li>• Export .html</li>
                <li>• Pubblicità attive</li>
              </ul>
              <button onClick={onStart} style={btn()}>Usa Free</button>
            </div>
            <div style={card(true)}>
              <h3>PRO</h3>
              <p style={{opacity:.8}}>Crescita e condivisione</p>
              <ul style={{opacity:.95, fontSize:14, lineHeight:1.6}}>
                <li>• No pubblicità</li>
                <li>• Export .zip</li>
                <li>• Più template (shooter, platform)</li>
              </ul>
              <a href={STRIPE_PAYMENT_LINK} style={btn()}>Upgrade – 5€/mese</a>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

function card(highlight=false){
  return {
    background: "rgba(255,255,255,.06)",
    border: highlight? "1px solid rgba(167,139,250,.6)":"1px solid rgba(255,255,255,.12)",
    borderRadius: 16,
    padding: 16
  };
}

function btn(outline=false, asLink=false){
  return {
    display:"inline-block",
    padding:"10px 14px",
    borderRadius:12,
    background: outline? "rgba(255,255,255,.06)" : "rgba(255,255,255,.1)",
    color:"#fff",
    border:"1px solid rgba(255,255,255,.12)",
    textDecoration:"none",
    cursor:"pointer"
  };
}

function Builder({isPro}){
  const [prompt, setPrompt] = useState("");
  const [config, setConfig] = useState(()=>parsePrompt("Runner futuristico nello spazio, difficile, avatar razzo"));
  const [lastScore, setLastScore] = useState(null);
  const [running, setRunning] = useState(true);
  const canvasRef = useRef(null);
  const stateRef = useRef(null);
  const width = 900, height = 360;

  useEffect(()=>{ // init
    const base = {
      groundY: height - 60,
      player: { x: 120, y: height - 60, vy: 0, size: 28, onGround: true },
      obstacles: [], clouds: [], score: 0, best: 0, gameOver: false,
    };
    base.clouds = Array.from({length:10},()=>({ x: Math.random()*width, y: 20+Math.random()*100, s: .3+Math.random() }));
    stateRef.current = base;
  },[config]);

  useEffect(()=>{
    const onKey = (e)=>{
      if([" ","Spacebar","ArrowUp"].includes(e.key) || ["Space","ArrowUp"].includes(e.code)){ e.preventDefault(); jump(); }
      if(e.key==="p"||e.key==="P") setRunning(r=>!r);
      if(e.key==="r"||e.key==="R") restart();
    };
    window.addEventListener("keydown", onKey);
    return ()=>window.removeEventListener("keydown", onKey);
  },[]);

  useRaf(running, (t)=>{
    tick( Math.min(32, (t-(Builder._last||t))) ); Builder._last=t;
  });

  function tick(dt){
    const s = stateRef.current; if(!s || s.gameOver) return;
    const ctx = canvasRef.current?.getContext("2d"); if(!ctx) return;

    // spawn & move
    const [gmin,gmax] = config.tuning.gap;
    const need = s.obstacles.length===0 || (s.obstacles[s.obstacles.length-1].x < width - rand(gmin,gmax));
    if(need){ const h=rand(20,48), w=rand(16,30), tall=Math.random()<.2; s.obstacles.push({ x: width+rand(0,30), y: s.groundY-h, w: tall? w*1.2:w, h: tall? h*1.6:h }); }
    s.obstacles.forEach(o=>o.x-=config.tuning.speed); s.obstacles = s.obstacles.filter(o=>o.x+o.w>0);
    s.clouds.forEach(c=>{ c.x-=c.s*.7; if(c.x<-40){ c.x=width+Math.random()*120; c.y=15+Math.random()*120; c.s=.3+Math.random(); } });

    // physics
    s.player.vy += config.tuning.gravity;
    s.player.y += s.player.vy;
    if(s.player.y>=s.groundY){ s.player.y=s.groundY; s.player.vy=0; s.player.onGround=true; }
    s.score += .1*config.tuning.speed;

    // collision
    for(const o of s.obstacles){
      if( s.player.x < o.x+o.w && s.player.x + s.player.size > o.x && s.player.y - s.player.size < o.y+o.h && s.player.y > o.y ){
        s.gameOver = true; setRunning(false); setLastScore(Math.floor(s.score));
      }
    }

    // draw
    ctx.fillStyle = config.palette.bg; ctx.fillRect(0,0,width,height);
    if(["space","neon","ice"].includes(config.theme)){
      for(let i=0;i<50;i++){ const x=(i*17+(s.score*.7))%width, y=(i*29)%height; ctx.globalAlpha=.2; ctx.fillStyle=config.palette.accent; ctx.fillRect(width-x,y,2,2); ctx.globalAlpha=1; }
    }
    ctx.globalAlpha=.7; ctx.fillStyle=config.palette.accent; s.clouds.forEach(c=>{ ctx.beginPath(); ctx.arc(c.x,c.y,14*c.s,0,Math.PI*2); ctx.fill(); }); ctx.globalAlpha=1;
    ctx.fillStyle=config.palette.ground; ctx.fillRect(0, s.groundY, width, 6);
    ctx.fillStyle=config.palette.accent; s.obstacles.forEach(o=>ctx.fillRect(o.x,o.y,o.w,o.h));
    ctx.font = `${s.player.size}px system-ui, Apple Color Emoji, Noto Color Emoji`; ctx.textBaseline="bottom"; ctx.fillText(config.avatar, s.player.x - s.player.size/2, s.player.y);
    ctx.fillStyle=config.palette.primary; ctx.font = `16px ui-monospace, SFMono-Regular, Menlo, monospace`; ctx.fillText(`SCORE: ${Math.floor(s.score)}`, 20,26); ctx.fillText(`P: pausa | R: restart | SPACE: salta`, 20,48);
    if(s.gameOver){ ctx.fillStyle=config.palette.primary; ctx.font = `28px ui-sans-serif, system-ui`; ctx.fillText("GAME OVER — premi R per ripartire", 160, 140); }
  }

  function jump(){ const s=stateRef.current; if(!s||s.gameOver) return; if(s.player.onGround){ s.player.vy = -config.tuning.jump; s.player.onGround=false; } }
  function restart(){ const s=stateRef.current; if(!s) return; s.obstacles=[]; s.score=0; s.gameOver=false; s.player={...s.player, x:120, y:height-60, vy:0, onGround:true}; setRunning(true); }

  return (
    <div style={{maxWidth:1100, margin:"0 auto", padding:"30px 20px"}}>
      {!isPro && <AdBox/>}
      <div style={{display:"grid", gap:16, gridTemplateColumns:"1fr"}}>
        <div style={{background:"rgba(255,255,255,.06)", border:"1px solid rgba(255,255,255,.12)", borderRadius:16, padding:16}}>
          <label style={{opacity:.8, fontSize:14}}>Descrivi il gioco</label>
          <textarea value={prompt} onChange={(e)=>setPrompt(e.target.value)} placeholder="Esempio: Runner nello spazio, difficile, avatar razzo"
            style={{width:"100%", marginTop:8, height:96, borderRadius:12, background:"rgba(255,255,255,.06)", border:"1px solid rgba(255,255,255,.12)", padding:12, color:"#fff"}}/>
          <div style={{display:"flex", gap:8, flexWrap:"wrap", marginTop:10}}>
            <button onClick={()=>setConfig(parsePrompt(prompt))} style={btn()}>Genera gioco</button>
            <button onClick={()=>downloadHTML(config)} style={btn()}>Esporta .html (Free)</button>
            <button disabled title="Solo per PRO" style={{...btn(), opacity:.5, cursor:"not-allowed"}}>Export .zip (PRO)</button>
          </div>
        </div>
        <div style={{display:"grid", placeItems:"center"}}>
          <canvas ref={canvasRef} width={width} height={height} style={{borderRadius:16, border:"1px solid rgba(255,255,255,.12)", boxShadow:"0 10px 30px rgba(0,0,0,.5)"}}/>
        </div>
      </div>
      {!isPro && <AdBox/>}
    </div>
  );
}

function AdBox(){
  useEffect(()=>{
    if(!ADSENSE_CLIENT) return;
    const id="adsense-script";
    if(!document.getElementById(id)){
      const s=document.createElement("script"); s.id=id; s.async=true;
      s.src=`https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${ADSENSE_CLIENT}`;
      s.crossOrigin="anonymous"; document.head.appendChild(s);
    }
  },[]);
  return (
    <div style={{margin:"10px 0", border:"1px solid rgba(255,255,255,.12)", background:"rgba(255,255,255,.05)", borderRadius:12, padding:14, textAlign:"center", opacity:.9}}>
      {ADSENSE_CLIENT ? <ins className="adsbygoogle" style={{display:"block"}} data-ad-client={ADSENSE_CLIENT} data-ad-slot="1234567890" data-ad-format="auto" data-full-width-responsive="true"></ins>
        : "Ad placeholder — aggiungi ADSENSE_CLIENT nel codice"}
    </div>
  );
}

function Footer(){
  return (
    <div style={{borderTop:"1px solid rgba(255,255,255,.08)", padding:"18px 20px", opacity:.7, fontSize:14}}>
      © Road2Game™ • Free con pubblicità • PRO senza ads, export .zip, più template.
    </div>
  );
}

// ---- Helpers ----
function parsePrompt(raw){
  const p=(raw||"").toLowerCase();
  let theme="neon";
  if(/(spazio|space|galaxy|cosmo|cosmico|astr)/.test(p)) theme="space";
  else if(/(foresta|forest|jungle|bosco|verde)/.test(p)) theme="forest";
  else if(/(deserto|desert|sabbia|dune)/.test(p)) theme="desert";
  else if(/(citt[aà]|city|metrop|urban|street)/.test(p)) theme="city";
  else if(/(ghiaccio|ice|neve|snow)/.test(p)) theme="ice";

  let difficulty="medium";
  if(/(imposs|hard|diffic|incubo|insane)/.test(p)) difficulty="hard";
  else if(/(facile|easy|beginner|relax)/.test(p)) difficulty="easy";

  let avatar="🟡";
  if(/(razzo|rocket|nave|navicella)/.test(p)) avatar="🚀";
  else if(/(gatto|cat|simba)/.test(p)) avatar="🐱";
  else if(/(cavallo|horse)/.test(p)) avatar="🐎";
  else if(/(ninja|samurai)/.test(p)) avatar="🥷";
  else if(/(auto|car|macchina|tesla)/.test(p)) avatar="🚗";

  const palettes={
    neon:{ bg:"#0a0a0f", ground:"#1a1b26", primary:"#22d3ee", accent:"#a78bfa" },
    space:{ bg:"#050510", ground:"#0f1020", primary:"#60a5fa", accent:"#f472b6" },
    forest:{ bg:"#071b12", ground:"#0b2a1a", primary:"#34d399", accent:"#86efac" },
    desert:{ bg:"#2d1908", ground:"#4a2a0a", primary:"#fbbf24", accent:"#fde68a" },
    city:{ bg:"#0b0b0e", ground:"#16181d", primary:"#93c5fd", accent:"#f59e0b" },
    ice:{ bg:"#08121f", ground:"#0f1e33", primary:"#7dd3fc", accent:"#c7d2fe" },
  };
  const palette = palettes[theme] || palettes.neon;
  const tuning = { easy:{speed:5,gap:[220,360],gravity:.65,jump:12.5}, medium:{speed:7,gap:[180,300],gravity:.7,jump:13.5}, hard:{speed:9,gap:[150,260],gravity:.78,jump:14.2} }[difficulty];
  const titleBase = raw?.trim()? raw.trim() : "Runner AI";
  const title = `${titleBase} — ${theme.toUpperCase()} ${difficulty.toUpperCase()}`;
  return { theme, difficulty, avatar, palette, tuning, title };
}
function rand(min,max){ return Math.random()*(max-min)+min; }
function useRaf(active, cb){ const ref=useRef(); useEffect(()=>{ let id; const loop=(t)=>{ cb(t); id=requestAnimationFrame(loop); }; if(active) id=requestAnimationFrame(loop); return ()=>cancelAnimationFrame(id); },[active,cb]); }
function downloadHTML(config){
  const html = `<!doctype html>
<html lang="it"><meta charset="utf-8"/><meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>${"${config.title}"}</title>
<style>html,body{margin:0;background:${"${config.palette.bg}"};color:#fff;font-family:system-ui}canvas{border-radius:16px;box-shadow:0 10px 30px rgba(0,0,0,.5);border:1px solid rgba(255,255,255,.12)}</style>
<canvas id="c" width="900" height="360"></canvas>
<script>
 const palette=${"${JSON.stringify(config.palette)}"}; const tuning=${"${JSON.stringify(config.tuning)}"}; const theme=${"${JSON.stringify(config.theme)}"}; const avatar=${"${JSON.stringify(config.avatar)}"};
 const width=900,height=360; let paused=false; const ctx=document.getElementById('c').getContext('2d');
 const s={ groundY:height-60, player:{x:120,y:height-60,vy:0,size:28,onGround:true}, obstacles:[], clouds:[], score:0, best:0, gameOver:false };
 for(let i=0;i<10;i++){ s.clouds.push({x:Math.random()*width,y:20+Math.random()*100,s:.3+Math.random()}) }
 function rand(a,b){ return Math.random()*(b-a)+a } function spawn(){ const need=s.obstacles.length===0 || s.obstacles[s.obstacles.length-1].x < width - rand(${ "${config.tuning.gap[0]}" }, ${ "${config.tuning.gap[1]}" }); if(need){ const h=rand(20,48),w=rand(16,30),tall=Math.random()<.2; s.obstacles.push({x:width+rand(0,30),y:s.groundY-h,w:tall?w*1.2:w,h:tall?h*1.6:h}); }}
 function jump(){ if(s.gameOver) return; if(s.player.onGround){ s.player.vy=-tuning.jump; s.player.onGround=false; }} function restart(){ const best=Math.max(s.best,Math.floor(s.score)); s.obstacles=[]; s.score=0; s.gameOver=false; s.best=best; s.player={...s.player,x:120,y:height-60,vy:0,onGround:true}; paused=false; }
 addEventListener('keydown',e=>{ if(e.code==='Space'||e.code==='ArrowUp'){ e.preventDefault(); jump() } if(e.key==='p'||e.key==='P') paused=!paused; if(e.key==='r'||e.key==='R') restart(); });
 let last=performance.now(); function loop(t){ const dt=Math.min(32,t-last); last=t; if(!paused){ spawn(); s.obstacles.forEach(o=>o.x-=tuning.speed); s.obstacles=s.obstacles.filter(o=>o.x+o.w>0); s.clouds.forEach(c=>{ c.x-=c.s*.7; if(c.x<-40){ c.x=width+Math.random()*120; c.y=15+Math.random()*125; c.s=.3+Math.random(); } }); s.player.vy+=tuning.gravity; s.player.y+=s.player.vy; if(s.player.y>=s.groundY){ s.player.y=s.groundY; s.player.vy=0; s.player.onGround=true; } s.score+=.1*tuning.speed; for(const o of s.obstacles){ if(s.player.x<o.x+o.w && s.player.x+s.player.size>o.x && s.player.y - s.player.size < o.y+o.h && s.player.y>o.y){ s.gameOver=true; paused=true; } } } ctx.fillStyle=palette.bg; ctx.fillRect(0,0,width,height); if(['space','neon','ice'].includes(theme)){ for(let i=0;i<50;i++){ const x=(i*17+(s.score*.7))%width, y=(i*29)%height; ctx.globalAlpha=.2; ctx.fillStyle=palette.accent; ctx.fillRect(width-x,y,2,2); ctx.globalAlpha=1; }} ctx.globalAlpha=.7; ctx.fillStyle=palette.accent; s.clouds.forEach(c=>{ ctx.beginPath(); ctx.arc(c.x,c.y,14*c.s,0,Math.PI*2); ctx.fill(); }); ctx.globalAlpha=1; ctx.fillStyle=palette.ground; ctx.fillRect(0,s.groundY,width,6); ctx.fillStyle=palette.accent; s.obstacles.forEach(o=>ctx.fillRect(o.x,o.y,o.w,o.h)); ctx.font=s.player.size+'px system-ui, Apple Color Emoji'; ctx.textBaseline='bottom'; ctx.fillText(avatar, s.player.x - s.player.size/2, s.player.y); ctx.fillStyle=palette.primary; ctx.font='16px ui-monospace'; ctx.fillText('SCORE: '+Math.floor(s.score),20,26); if(s.gameOver){ ctx.font='28px ui-sans-serif'; ctx.fillText('GAME OVER — premi R per ripartire',160,140); } requestAnimationFrame(loop); } requestAnimationFrame(loop);
</script>`;
  const blob = new Blob([html], { type: "text/html" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = `${config.title.replace(/[^a-z0-9\-\s]/gi, "_").replace(/\s+/g, "-")}.html`;
  document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
}
