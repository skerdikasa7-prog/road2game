# Road2Game™ Deluxe

- Landing page + Builder integrati
- Free con pubblicità (placeholder) • PRO con Stripe (Payment Link)
- Backend minimal /api/verify-session per attivare PRO dopo il pagamento

## Deploy (Vercel)
1) Upload progetto
2) Env: STRIPE_SECRET_KEY=sk_test_xxx
3) Redirect in Stripe: https://YOUR-DEPLOY.vercel.app/?session_id={CHECKOUT_SESSION_ID}

## Note
- Per AdSense: imposta ADSENSE_CLIENT in App.jsx
