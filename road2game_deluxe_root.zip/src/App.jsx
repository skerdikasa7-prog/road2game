import React, { useState, useEffect } from "react";
const STRIPE_PAYMENT_LINK = "https://buy.stripe.com/aFa4gtfbv8sS2y1d9Ygfu03";
export default function App(){
  const [isPro, setIsPro] = useState(false);
  useEffect(()=>{
    const sid = new URLSearchParams(window.location.search).get("session_id");
    async function verify(s){ try{ const r=await fetch(`/api/verify-session?session_id=${s}`); if(r.ok){ const d=await r.json(); if(d?.isPro){ localStorage.setItem("gb_is_pro","1"); setIsPro(true);} } }catch(e){console.error(e);} }
    if(sid) verify(sid); if(localStorage.getItem("gb_is_pro")==="1") setIsPro(true);
  },[]);
  return (<div style={{minHeight:"100vh",background:"#000",color:"#fff",fontFamily:"system-ui"}}>
    <div style={{padding:"20px",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
      <h1 style={{margin:0}}>Road2Game™</h1>
      {isPro? <span style={{padding:"6px 10px",border:"1px solid #1db954",borderRadius:10,background:"rgba(29,185,84,.15)"}}>PRO attivo</span>
            : <button onClick={()=>location.href=STRIPE_PAYMENT_LINK} style={{padding:"10px 14px",borderRadius:10,border:"1px solid #444",background:"#222",color:"#fff"}}>Upgrade PRO – 5€/mese</button>}
    </div>
    <div style={{padding:"20px"}}>
      <p>Landing base. Premi Upgrade per testare il flusso Stripe, oppure deploya e personalizza il builder.</p>
    </div>
  </div>);
}
