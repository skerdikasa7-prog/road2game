import type { VercelRequest, VercelResponse } from "@vercel/node";
import Stripe from "stripe";
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY as string, { apiVersion: "2024-06-20" });
export default async function handler(req: VercelRequest, res: VercelResponse) {
  const session_id = (req.query.session_id as string) || "";
  if (!session_id) return res.status(400).json({ error: "missing session_id" });
  try {
    const session = await stripe.checkout.sessions.retrieve(session_id, { expand: ["subscription"] });
    const paid = session.payment_status === "paid";
    let isPro = false;
    if (session.mode === "subscription" && session.subscription && typeof session.subscription === "object") {
      const status = session.subscription.status; isPro = status === "active" || status === "trialing";
    } else if (session.mode === "payment") { isPro = paid; }
    if (isPro) { res.setHeader("Set-Cookie",`r2g_pro=1; Path=/; Max-Age=${30*24*60*60}; SameSite=Lax; HttpOnly`); return res.status(200).json({ isPro: true }); }
    return res.status(200).json({ isPro: false });
  } catch (e:any) { console.error(e?.message||e); return res.status(500).json({ error: "server_error" }); }
}
